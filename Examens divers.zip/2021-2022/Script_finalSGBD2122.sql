create table clients ( 
CodeClient number(10) primary key , 
nom varchar(30) , prenom varchar(30),
DateNaissance date, Fonction varchar(30)) ; 

create table Vols ( 
IdVol number(10) primary key , 
villeDepart varchar(30), villeDestination varchar(30),
 dateDepart date,heureDepart date, dateArrivee date,heureArrivee date) ; 

create table Circuits ( 
idCircuit number(5) primary key , 
intitule varchar(30), description varchar(30), prixCircuit number,
 nbPlaceDisponible number, codeVol number(10) references vols(idvol));

create table Reservations(idReservation number(10) primary key ,codeClient number(10) references clients3 (CodeClient) ,
codeCircuit number(10) references Circuits ( 
idCircuit), dateReservation date ,
nbPlaceReserve number , 
Acompte number , etatReservation varchar(30), 
modePayement varchar(30));


insert into clients values ( 08484937 , 'bensalah','Mohamed', to_date('26/03/2001','DD/MM/YYYY'), 'ingenieur' ); 
insert into clients values ( 03494389 , 'Karoui', 'Ahmed' , to_date('06/02/2000','DD/MM/YYYY') , 'technicien'); 
insert into clients values ( 03498381 , 'benamor', 'hamdi' , to_date('12/05/1989','DD/MM/YYYY') , 'architecte'); 
insert into clients values ( 03498382 , 'bensaid', 'salah' , to_date('12/09/2000','DD/MM/YYYY') , 'directeur'); 
insert into clients values ( 03498383 , 'yamen', 'sami' , to_date('2/12/1989','DD/MM/YYYY') , 'enseignant'); 
insert into clients values ( 03498384 , 'zawa', 'wiem' , to_date('1/01/2001','DD/MM/YYYY') , 'architecte'); 


insert into Vols values (10, 'tunis', 'istanbul', to_date('20/03/2022','DD/MM/YYYY'), to_date('20/03/2022 15/10','DD/MM/YYYY hh24/mi'), to_date('26/03/2022','DD/MM/YYYY'), 
to_date('26/03/2022 12/10','DD/MM/YYYY hh24/mi') );
insert into Vols values (11, 'tunis', 'paris', to_date('26/05/2022','DD/MM/YYYY'), to_date('26/05/2022 15/10','DD/MM/YYYY hh24/mi'), to_date('01/04/2022','DD/MM/YYYY'), 
to_date('01/04/2022 12/10','DD/MM/YYYY hh24/mi') );
insert into Vols values (12, 'tunis', 'italie', to_date('26/05/2022','DD/MM/YYYY'), to_date('26/05/2022 15/10','DD/MM/YYYY hh24/mi'), to_date('01/04/2022','DD/MM/YYYY'), 
to_date('01/04/2022 12/10','DD/MM/YYYY hh24/mi') );


insert into Circuits values (0001, 'Rome le reve', 'voyage de reve', 5520, 25, 12);
insert into Circuits values (0002, 'Istambul l''amour', 'voyage en amoureux', 2250, 25, 10);
insert into Circuits values (0003, 'Paris Lumiere', 'voyage pour decouvrir Paris', 2100, 25, 11);
insert into Circuits values (0004, 'Grec pour la vie', 'Autre sidi bousiid', 1500, 25, null);
insert into Circuits values (0005, 'Dubai l''or', 'voyage luxueux', 10000, 25, null);


insert into Reservations values (100,08484937,0001, to_date('20/01/2022','DD/MM/YYYY'), 5, 1200, 'imcomplet', 'comptant' ); 
insert into Reservations values (102,03498381,0002, to_date('2/02/2022','DD/MM/YYYY'), 6, 500, 'en cours', 'comptant' ); 

--1-create sequence seq_res INCREMENT BY 1 start with 1 maxvalue 300 nocycle;

--2-create  view v_details_res as select nom, prenom, intitule 
from clients c join reservations r on r.codeClient=c.codeClient join circuits cr on cr.idCircuit=r.codeCircuit where etatReservation='confirme' with read only;


-----3
----a
/*
create or replace function fn_nb return integer
is
nb integer;
begin
select count(*) into nb  from circuits where idCircuit not in (select distinct idCircuit from Reservations);
return nb;
end;
/
*/
-----b

-----select fn_nb "nb circuit" from dual;

-----ou bien 
/*
set serveroutput on 
declare
v_nb integer;
begin
v_nb:= fn_nb; 
dbms_output.put_line (v_nb);
end;
/
*/

---------4
/*
set serveroutput on 
declare
cursor cur_vl is select villeDepart VD, count(*) nbvilledep from vols group by villedepart having count(*)>50;
begin
for i in cur_vl
loop
dbms_output.put_line( 'la ville de depart est :' || i.VD|| 'le nombre est' || i.nbvilledep);
end loop;
end;
/
*/
-------------------------------



--------5
/*
create or replace procedure proc_insertion_res (v_cli Reservations.codeClient%type, v_cir Reservations.codeCircuit%type, 
nb Reservations.nbPlaceReserve%type, vacompte Reservations.Acompte%type)
is
verif Reservations.codeClient%type;
prix Reservations.Acompte%type;
exception_accompte exception; 
begin
select CodeClient into verif from clients where CodeClient=v_cli;
select prixCircuit into prix from circuits where idCircuit=v_cir;
if (vacompte < prix/3) then 
raise exception_accompte;
end if;
insert into reservations values(seq_res.nextval, v_cli, v_cir, sysdate, nb, vacompte, null,null);
commit; 
exception
when dup_val_on_index then 
dbms_output.put_line(' code circuit inexistant');
when no_data_found then
dbms_output.put_line('code client inexistant or code circuit inexistant');
when exception_accompte then dbms_output.put_line('verifiez le montant de l''acompte');
end;
/
*/

------------------6
/*

create or replace procedure proc_top_clients (total_res out integer)
is
cursor cur_topthree is select count(*) nb, codeClient cc from reservations group by codeClient order by 1 desc;
begin
total_res :=0;
for j in cur_topthree
loop
total_res := total_res+ j.nb;
exit when cur_topthree%rowcount=3;
dbms_output.put_line('le code client est :'||j.cc||'_'||'ayant le nombre des revervations est :'||j.nb);
end loop;
end;
/
*/

--Appel
/*
set serveroutput on 
declare
tot integer;
begin
proc_top_clients (tot);
dbms_output.put_line(tot);
end;
/
*/

------7
/*
CREATE OR REPLACE TRIGGER TRIG_NB_PLACE
AFTER
INSERT OR DELETE ON RESERVATIONS
FOR EACH ROW 
BEGIN
IF INSERTING THEN 
UPDATE CIRCUITS SET nbPlaceDisponible = nbPlaceDisponible-1 where idCircuit=:new.codeCircuit ;
ELSE 
UPDATE CIRCUITS SET nbPlaceDisponible = nbPlaceDisponible+1 where idCircuit=:old.codeCircuit ;
END IF;
END;
/
*/

-----8
/*
create or replace trigger trig_control
before 
delete or update or insert on vols
for each row
when (new.dateDepart > new.dateArrivee)
begin
if (to_char(sysdate,'dd/mm')='01/01') or (to_char(sysdate, 'dd/mm')='01/05') then 
raise_application_error(-2000,'Interdit de faire toute modification');
end if;
end;
/
*/
